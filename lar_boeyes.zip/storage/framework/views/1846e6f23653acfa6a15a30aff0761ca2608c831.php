 <header>
        <div class="container-fluid">
            <div class="col-md-3">
                <img src="<?php echo url('public/backend/images/2.png'); ?>" alt="Logo alt" height="67">
            </div>
            <div class="col-md-9" style="line-height: 67px;">
                <p style="float: right;"><a href="<?php echo url('logout'); ?>">Đăng xuất</a></p>
            </div>
        </div>
</header>