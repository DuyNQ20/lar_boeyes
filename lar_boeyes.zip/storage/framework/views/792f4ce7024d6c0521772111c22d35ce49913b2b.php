<?php $__env->startSection('content-doctor'); ?>
<!-- bang bieu do -->
<div class="panel panel-primary" >
	<div class="panel panel-heading boxheader"> 
	Biểu diễn độ cận thị của học sinh HELLO</div>
	<div class="panel panel-body">
		<div class="seach-school">
			<form class="form-horizontal"  method="POST"  >
				<div class="form-group col-md-6">
					<label class="control-label col-md-4">Chọn trường:</label>
					<div class="col-md-8"> 
						<select class="form-control col-md-12" id="selector">
							<?php foreach($schools as $school): ?>
							<option value="<?php echo $school->school_id; ?>"> <?php echo $school->school_name; ?> </option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="form-group col-md-6">
					<label class="control-label col-md-4">Mã học sinh:</label>
					<div class="col-md-6">   
						<input type="text" id="student_code" name="student_code" value="" class="form-control">
					</div>
					<input  type="button" onclick="getStudentChart()" class="btn btn-primary col-md-2" value="Xem" name="">
				</div>
			</form>
			</div>
		</div>
		<div id="chart-container">
			<canvas id="line-chart"></canvas>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.doctor.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>