<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script type="text/javascript" src="{!! url('public/backend/js/Chart.min.js') !!} "></script>
    <script type="text/javascript" src="{!! url('public/backend/js/jquery-3.3.1.min.js') !!}"></script>
    <script type="text/javascript" src="{!! url('public/backend/js/customer.js') !!}"></script>
    <link rel="stylesheet" type="text/css" href="{!! url('public/backend/css/QuanLiThiLucCSS.css') !!}">
    <link rel="icon" href="http://www.thuthuatweb.net/wp-content/themes/HostingSite/favicon.ico" type="image/x-ico"/>
</head>
<body>
@yield('content')
</body>
</html>

    
   
  