<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "tbl_account";
    protected $fillable = [
       'acc_username','acc_code', 'acc_password'
   ];
   public $timestamps = false;

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
       'acc_password'
   ];


   public function getAuthPassword()
   {
        return $this->acc_password;
    }
}
